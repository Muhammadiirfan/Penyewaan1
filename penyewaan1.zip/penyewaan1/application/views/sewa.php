<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Penyewaan Lapangan</title>
	<meta name="" content="">
</head>
<body>
	<h1>Penyewaan Lapangan </h1>
	<b>Pilihan Menu:</b>
	<ul>
		<li><?php echo anchor('Sewa/tampil_lapangan', 'Tampil Lapangan');?></li>
		<li><?php echo anchor('Sewa/tambah_lapangan', 'Tambah Lapangan');?></li>
	</ul>
</body>
</html>