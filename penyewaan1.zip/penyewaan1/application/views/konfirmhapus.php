<?php
echo "<h2>Konfirmasi hapus data penyewa</h2>";
echo "<p>Apakah data penyewa berikut ini akan dihapus?</p>";
echo "<table border=1>";
echo "<tr><th>NO</th> <th>ID lapangan</th> <th>Nama penyewa</th> <th> DP </th> <th> Waktu </th> <th> Alamat </th></tr>";
$no=0;
foreach ($datalapangan as $isi)
    {
        $no++;
    echo "<tr>";
            echo "<td>$no</td>";
            echo "<td>$isi->ID_lapangan</td>";
            echo "<td>$isi->Nama</td>";
            echo "<td>$isi->DP</td>";
            echo "<td>$isi->Waktu</td>";
            echo "<td>$isi->Alamat</td>";
    echo "</tr>";
    }
echo "</table>";
echo "<p>".anchor('Sewa/hapus_lapangan/'.$isi->ID_lapangan, 'Ya')." | ";
echo anchor('sewa/tampil_lapangan', 'Tidak')."</p>";
?>