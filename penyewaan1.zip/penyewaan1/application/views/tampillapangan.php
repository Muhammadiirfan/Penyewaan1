<?php
echo "<h2>Tampil Daftar Penyewaan Lapangan</h2>";
echo "<table border=1>";
echo "<tr><th>NO</th> <th>ID Lapangan</th> <th>Nama Penyewa</th> <th> Dp </th> <th> Waktu </th> <th> Alamat </th><th>Aksi</th></tr>";
$no=0;
foreach ($datalapangan as $isi)
    {
        $no++;
    echo "<tr>";
            echo "<td>$no</td>";
            echo "<td>$isi->ID_lapangan</td>";
            echo "<td>$isi->Nama</td>";
            echo "<td>$isi->DP</td>";
            echo "<td>$isi->Waktu</td>";
            echo "<td>$isi->Alamat</td>";
            echo "<td>";
            echo anchor('sewa/koreksi_lapangan/'.$isi->ID_lapangan, 'Edit')." | ";
            echo anchor('sewa/konfirm_hapus_lapangan/'.$isi->ID_lapangan, 'Hapus');
            echo "</td>";
    echo "</tr>";
    }
echo "</table>";
echo "<p>".anchor('sewa', 'Kembali')."</p>";
?>