<?php
class Sewa extends CI_Controller
{
	function __construct()
	{
	parent::__construct();
	}
	function index()
		{
			$this->load->view('sewa');
		}
    function tampil_lapangan()
	{
		 $kode='all';
		 $this->load->model('lapangan');
		 $data_lapangan['datalapangan']=$this->lapangan->tampil_data_lapangan($kode); 
		 $this->load->view('tampillapangan',$data_lapangan);
	}
	function tambah_lapangan()
	{
		$this->load->view('tambahlapangan');
	}
	function simpan_lapangan()
	{
		if (isset($_POST['mysubmit'])){
			$data = array(
				 'ID_lapangan' => $this->input->post('ID_lapangan'),
				 'Nama' => $this->input->post('Nama'), 
				 'DP' => $this->input->post('DP'),
				 'Waktu' => $this->input->post('Waktu'),
				 'Alamat' => $this->input->post('Alamat'),
				 'mode' => $this->input->post('mode')
			);
			$this->load->model('lapangan');
			$hasil=$this->lapangan->simpan_data_lapangan($data);
			if ($hasil){
				echo "Simpan data berhasil";
			}else{
				echo "Simpan data gagal";
			}
			echo "<br/>";
			echo anchor('sewa', 'Kembali');
		}
	}
	function koreksi_lapangan($kd)
	{
		$this->load->model('lapangan');
		$data_lapangan['datalapangan']=$this->lapangan->tampil_data_lapangan($kd); 
		$this->load->view('koreksilapangan',$data_lapangan);
	}
	function konfirm_hapus_lapangan($kd)
	{
		$this->load->model('lapangan');
		$data_lapangan['datalapangan']=$this->lapangan->tampil_data_lapangan($kd); 
		$this->load->view('konfirmhapus',$data_lapangan);
	}
	function hapus_lapangan($kd)
	{
		$this->load->model('lapangan');
				$hasil=$this->lapangan->hapus_data_lapangan($kd);
		if ($hasil){
				echo "Hapus data berhasil";
		}else{
				echo "Hapus data gagal";
		}
		echo "<br/>";
		echo anchor('sewa', 'Kembali');
	}
}
?>