<?php
class Lapangan extends CI_Model
{
	public function tampil_data_lapangan($kode)
	{
		if ($kode=='all'){
			$hasil=$this->db->get('sewa_lapangan');
		}else{
			$this->db->where('ID_lapangan',$kode);
			$hasil=$this->db->get('sewa_lapangan');
		}
	return $hasil->result();
 }
	public function simpan_data_lapangan($data)
{
		if ($data['mode']=='baru'){
			unset($data['mode']);
			$hasil=$this->db->insert('sewa_lapangan', $data); 
		}else{
			unset($data['mode']);
			$this->db->where('ID_lapangan',$data['ID_lapangan']);
			$hasil=$this->db->update('sewa_lapangan', $data); 
		}
		return $hasil;
	}
	public function hapus_data_lapangan($kode)
	{
		$this->db->where('ID_lapangan', $kode);
		$hasil=$this->db->delete('sewa_lapangan'); 
		return $hasil;
	}
}
?>